from timer import Timer

t = Timer()

t.start()

# Insert the routine to time
for n in range (1,100000):
    i = (n*n)/46.3
    
t.stop()