# timer2.py

import time

from timer2 import Timer2

t = Timer2(text="You waited {:.2f} seconds")

t.start()

# Insert the routine to time
for n in range (1,100000):
    i = (n*n)/46.3
    
t.stop()