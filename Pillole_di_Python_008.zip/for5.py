count = 0
for variabile in [3, 41, 12, 9, 74, 15]:
    count = count + 1
print('Count: ', count)