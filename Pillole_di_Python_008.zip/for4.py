lista_nomi = ['Luigi', 'Marco', 'Patrizia', 'Giovanni', 'Valentina']

for nome in lista_nomi:
    print (nome)
    
print("Finito!")