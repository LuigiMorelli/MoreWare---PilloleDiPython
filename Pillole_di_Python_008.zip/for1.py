frutto = "albicocca"
print ("la stringa frutto è lunga ",len(frutto))
for lettera in frutto:
    print(lettera)