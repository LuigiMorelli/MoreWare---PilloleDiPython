#for i in range(6):
#    print (i)

#for i in range (15, 46):
#    print (i)
    
#for i in range (20, 101, 10):
#    print (i)
    
    
for i in range (0,100,11):
    print(i)