contatore = 0
frutto = "albicocca"
esempio = 'c'
print ("la stringa frutto è lunga",len(frutto))

for lettera in frutto:
    print(lettera)
    if lettera == esempio:
        contatore = contatore + 1
        
print("La lettera", esempio, "appare", contatore, "volte")
print()