print("Giochiamo assieme!")
print("Cercherò di indovinare se il numero che immetterai sia alto, medio o basso.")
numero = int(input("Immetti il tuo numero : "))
if numero < 10:
    print("Numero basso!")
elif numero > 100:
    print("Numero alto!")
else:
    print("Numero medio!")