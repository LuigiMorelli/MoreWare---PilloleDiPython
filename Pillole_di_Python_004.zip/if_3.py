velocità = int(input("Immetti la tua velocità "))
#Autostrada = True
Autostrada = False
if velocità >= 130:
    print("Prenderai sicuramente una multa!")
elif Autostrada:
    print("Se sei in autostrada va bene!")
else:
    print("Non sei in autostrada, rischi di prendere una multa!")