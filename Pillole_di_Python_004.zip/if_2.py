velocità = int(input("Immetti la tua velocità "))
if velocità >= 130:
    print("Prenderai una multa!")
else:
    print("Se sei in autostrada va bene!")