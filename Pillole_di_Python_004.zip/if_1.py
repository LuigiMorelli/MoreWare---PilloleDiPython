velocità = int(input("Immetti la tua velocità "))
if velocità >= 130:
    print("Prenderai una multa!")
    print(1)
print(2)

               