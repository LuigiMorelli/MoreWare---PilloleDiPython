import string
from PyPDF2 import PdfFileReader
import docx
#from openpyxl import load_workbook

doc = list()

def load_txt(f):
    fhand = open(f)
        
    global doc
    inp = fhand.read()
    fhand.close()
    #print(inp)
    for d in inp.split(' '):
        d = d.lower()
        d = d.strip()
        d = d.translate(d.maketrans('', '', string.punctuation))
        d = d.translate(d.maketrans('', '', '”'))
        d = d.translate(d.maketrans('', '', '\n'))
        doc.append(d)
    print(doc)
        
def load_doc(f):
    doc1 = docx.Document(f)
        
    fullText = []
    for para in doc1.paragraphs:
        fullText.append(para.text)
    # fullText è una lista di paragrafi.
    # Occorre inserire le parole contenute in ciascun paragrafo all'interno di una unica lista   
    for p in fullText:
        dati = p.split(' ')
        for d in dati:
            d = d.lower()
            d = d.strip()
            d = d.translate(d.maketrans('', '', string.punctuation))
            d = d.translate(d.maketrans('', '', '”'))
            d = d.translate(d.maketrans('', '', '\n'))
            doc.append(d)
    print(doc)
      
def load_pdf(f):
    pdf_path = (f)    

    pdf = PdfFileReader(str(pdf_path))

    for page in pdf.pages:
        text = (page.extractText())

    for d in text.split(' '):
        d = d.lower()
        d = d.strip()
        d = d.translate(d.maketrans('', '', string.punctuation))
        d = d.translate(d.maketrans('', '', '”'))
        d = d.translate(d.maketrans('', '', 'œ'))
        d = d.translate(d.maketrans('', '', '•'))
        d = d.translate(d.maketrans('', '', '\n'))
        d = d.translate(d.maketrans('', '', 'ﬂ'))
        d = d.translate(d.maketrans('', '', 'ﬁ'))
        d = d.translate(d.maketrans('', '', '™'))
        doc.append(d)
    print(doc)
    
load_txt("commedia.txt")
load_doc("commedia.docx")
load_pdf("commedia.pdf")