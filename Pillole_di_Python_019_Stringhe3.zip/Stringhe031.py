# Esempio di uso metodo .find

data = 'From stephen.marquard@uct.ac.za Sat Jan 5 09:14:16 2008'
atpos = data.find('@')
print(atpos) #21

sppos = data.find(' ',atpos)
print(sppos) #31

host = data[atpos+1:sppos]
print(host)   #uct.ac.za

print("---")

# Esempio di uso operatore di formato

camels = 42
print("I have spotted %d camels." % camels)

print("---")

# Esempio di uso operatore di formato con valori multipli

giorno = "Lunedì"
data = "20-09-2020"
ora = 15
minuti = 30
temp = 20.4
print ("Oggi è %s %s, sono le %i:%i ed abbiamo %4.2f °C" % (giorno, data, ora, minuti, temp))

print ("--- Stampa tabellare ---")
valori = (15, 17.832, 11.2, 20.43)

print ("\n valore 1 = %5.2f \n valore 2 = %5.2f\n valore 3 = %5.2f\n valore 4 = %5.2f\n" % valori)

# Errori possibili:
# print( '%d %d %d" % (1, 2) )
# TypeError: not enough arguments for format string
# print( '%d' % 'dollari' )
# TypeError: %d format: a number is required, not str

