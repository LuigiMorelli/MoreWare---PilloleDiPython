# Range completo di tipi numerici

# small integer (contenuti in una machine word)
>>> 123
123

# big integer
>>> 1 << 160
1461501637330902918203684832716283019655932542976

# floating point
>>> 1.23e6
1230000.0

# complex numbers
>>> (1 + 2j) * 4j
(-8+4j)