import os

# Elenca il contenuto della root directory
print(os.listdir('/'))

# Stampa la directory corrente
print(os.getcwd())

# Apre e legge un file dalla SD card
with open('/sd/readme.txt') as f:
    print(f.read())