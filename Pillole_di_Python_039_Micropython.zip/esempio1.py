from machine import Pin

# Crea un pin di I/O in modalità output
p = Pin('X1', Pin.OUT)

# Modifica il pin
p.high()
p.low()