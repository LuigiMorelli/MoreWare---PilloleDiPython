# MicroPython ha un inline assembler

import micropython

# Definiamo una funzione in Thumb-code inline-assembler
@micropython.asm_thumb
def asm_add(r0, r1):
    add(r0, r0, r1)

# Usiamola come una normale funzione in Python
total = asm_add(1, 2)