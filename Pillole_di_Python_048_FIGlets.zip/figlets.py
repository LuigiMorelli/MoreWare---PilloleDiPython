import sys
from pyfiglet import Figlet
import random

def error():
    print("Invalid usage")
    sys.exit(1)


if len(sys.argv) in [1, 3]:
    # Instantiate an object
    figlet = Figlet()

    # and copy the font list in a list of fonts
    FontList = figlet.getFonts()

    f = ""

    # 2 parameters
    if len(sys.argv) == 3:
        if sys.argv[1] in ["-f", "--font"]:
            f = sys.argv[2]

        if f not in FontList:
            error()
    else:
        # len(argv) == 1, load a random font
        a = random.randint(0, len(FontList) - 1)
        f = FontList[a]

    s = input("Input: ")

    # Get the name of the font from argv[1]
    figlet.setFont(font=f)

    print(figlet.renderText(s))
else:
    error()

# for f in FontList:
#     print(f)
# print(len(FontList))