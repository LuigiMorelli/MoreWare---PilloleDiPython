from pyfiglet import Figlet
from time import sleep

# Instantiate the object
figlet = Figlet()

# and copy the font list in a list of fonts
FontList = figlet.getFonts()

for f in FontList:
    print("Font: ", f)
    figlet.setFont(font=f)
    s = "MoreWare"
    print(figlet.renderText(s))
    sleep(2)
