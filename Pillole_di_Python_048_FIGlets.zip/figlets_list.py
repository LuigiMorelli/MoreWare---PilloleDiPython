from pyfiglet import Figlet
from time import sleep

# Instantiate the object
figlet = Figlet()

# and copy the font list in a list of fonts
FontList = figlet.getFonts()
Font1 = ['3-d', 'acrobatic', 'avatar', 'banner3-D', 'big', 'binary', 'block', 'bubble', 'bulbhead', 'cosmic', 'cricket',
         'cybermedium', 'digital', 'doh', 'doom', 'dotmatrix', 'drpepper', 'eftirobot', 'epic', 'goofy', 'isometric1',
          'italic', 'katakana', 'larry3d', 'letters', 'linux', 'mirror', 'nancyj-underlined', 'poison', 'roman', 'rounded',
          'rozzo', 'script', 'serifcap', 'shadow', 'slant', 'slscript', 'speed', 'starwars', 'stop', 'straight', 'thin',
          'tinker-toy', 'tombstone', 'trek', 'twopoint', 'usaflag']

for f in Font1:
    print("Font: ", f)
    figlet.setFont(font=f)
    s = "MoreWare"
    print(figlet.renderText(s))
    sleep(2)
