from openpyxl import Workbook
wb = Workbook()

# Attiva il foglio
ws = wb.active

# E' possibile inserire i dati direttamente nelle celle
ws['A1'] = 42

# E' anche possibile inserire intere righe (in questo caso in riga #2)
ws.append([1, 2, 3])

# I tipi di Python vengono convertiti automaticamente
import datetime
ws['A3'] = datetime.datetime.now()

# E' infine possibile modificare campi inseriti in precedenza
ws['B2'] = 222  # Prima era 2

# Il file appena creato viene salvato con un nome a piacere
wb.save("sample.xlsx")