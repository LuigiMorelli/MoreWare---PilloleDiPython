vettore = []
f = open("number_test.txt", "r")
for l in f:
    vettore.append(l.strip("\n"))
    #vettore.append(int(l))
f.close()

print(vettore)
vettore.sort()
print(vettore)