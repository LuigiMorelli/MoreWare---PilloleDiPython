import random

random.seed()

f = open ("number_test.txt", "w")
for i in range (10000):
    f.write(str(random.randint(0,100000)))
    f.write("\n")
f.close()

f = open("number_test.txt", "r")
for l in f:
    print(l.strip("\n"))
f.close()
    