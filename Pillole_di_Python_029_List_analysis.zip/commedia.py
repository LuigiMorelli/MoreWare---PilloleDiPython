vettore = []
f = open("commedia.txt", "r")
for l in f:
    vettore.append(l.strip("\n"))
f.close()

print(vettore)

# Conteggio righe
tot_righe = (len(vettore))

# Conteggio parole e caratteri - Non serve riaprire il file
tot_parole = 0
tot_caratteri = 0
for l in vettore:
    parole = l.split(" ")
    tot_parole = tot_parole + len(parole)
    # Conteggio caratteri
    for w in parole:
        tot_caratteri = tot_caratteri + len(w)
        
print("Il testo contiene %i righe, %i parole e %i caratteri." % (tot_righe, tot_parole, tot_caratteri))