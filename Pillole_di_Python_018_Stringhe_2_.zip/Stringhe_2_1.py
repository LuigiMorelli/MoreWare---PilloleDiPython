# Esempi di slicing sulle stringhe

s = "Peter, Paul, and Mary"

print (s[0:5])
print (s[7:11])
print (s[17:21])

print ("---")

print (s[0:15])

print ("---")

print (s[15:])

print ("---")

print (s[:])
