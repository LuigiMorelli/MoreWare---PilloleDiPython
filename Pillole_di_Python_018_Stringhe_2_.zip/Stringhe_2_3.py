#il metodo find sulle stringhe
frutto = "banana"

index = frutto.find("a")
print(index)

print("---")

index = frutto.find("na")
print(index)

print("---")

index = frutto.find("na", 3)
print(index)

print("---")

index = frutto.find("pesca")
print(index)