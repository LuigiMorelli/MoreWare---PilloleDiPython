# Confronto tra stringhe

s = "banana"
parola = "banana"
# parola = "ananas"
# parola = "pesca"
# parola = "Pesca"
if parola == s:
    print (parola, "= ", s)
elif parola < s:
    print (parola, "< ", s)
else:
    print (parola, "> ", s)
