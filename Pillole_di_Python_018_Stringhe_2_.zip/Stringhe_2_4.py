# Altri metodi caratteristici delle stringhe

s = "banana"

print (s.capitalize())

print("---")

maiuscolo = s.upper()
print (maiuscolo)

print("---")

esempio = "    eccoci qui   "
print (esempio)
print (esempio.strip())

print("---")

saluto = "Buongiorno!"
print (saluto.startswith("buon"))
print (saluto.startswith("Buon"))

print (saluto.lower().startswith("buon"))
