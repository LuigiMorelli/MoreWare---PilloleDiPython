# Python program to show time by 
# perf_counter_ns() 
from time import perf_counter_ns

# Start the stopwatch / counter 
t1_start = perf_counter_ns()

# Insert the routine to time
for n in range (1,100000):
    i = (n*n)/46.3

# Stop the stopwatch / counter 
t1_stop = perf_counter_ns() 
  
elapsed = t1_stop - t1_start
print("Elapsed time:", elapsed, 'ns, (', elapsed/1000, 'us)'  )