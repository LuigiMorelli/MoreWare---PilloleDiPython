import time
seconds = time.time()
print("Secondi dal 1-1-1970 =", seconds)

# ctime(secondi) - seconds passed since epoch
local_time = time.ctime(seconds)
print("Local time:", local_time)

# sleep()
print("This is printed immediately.")
time.sleep(2.4)
print("This is printed after 2.4 seconds.")

# localtime()
result = time.localtime(seconds)
print("result:", result)
print("\nyear:", result.tm_year)
print("tm_hour:", result.tm_hour)

# Molte funzioni del modulo time, come gmtime(), asctime() etc.
# richiedono o restituiscono come argomento un oggetto di tipo  time.struct_time.

# mktime(t)
# il metodo mktime acquisisce come parametro un oggetto t di tipo struct_time
# (come quello visto in precedenza) o un insieme di 9 valori fissi corrispondenti alla struct
# e restituisce i secondi trascorsi dal 1-1-1970.
# Si tratta dell'inverso di localtime()
t = (2018, 12, 28, 8, 44, 4, 4, 362, 0)

local_time = time.mktime(t)
print("Local time:", local_time)

# asctime(t)
# il metodo time acquisisce come parametro un oggetto t di tipo struct_time
# (come quello visto in precedenza) o un insieme di 9 valori fissi corrispondenti alla struct
# e restituisce una stringa formattata con la data e l'ora.
t = (2018, 12, 28, 8, 44, 4, 4, 362, 0)

data = time.asctime(t)
print("Data odierna:", data)

# strftime()
# Qualora desiderassimo una data formattata in un certo modo, utilizziamo strftime()
data_attuale = time.localtime() # get struct_time
time_string = time.strftime("%m/%d/%Y, %H:%M:%S", data_attuale)

print(time_string)

# strptime()
# Possiamo anche acquisire una stringa che rappresenta data /ora
# ed inserirla nella struttura struct_time
time_string = "21 June, 2018"
result = time.strptime(time_string, "%d %B, %Y")

print(result)