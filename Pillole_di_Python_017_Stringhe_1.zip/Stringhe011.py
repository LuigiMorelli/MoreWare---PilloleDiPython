stringa = "Buongiorno a tutti"
print ("Ciascun carattere è posto di fianco al successivo")
print ("e viene letto in sequenza scorrendo la stringa")
print ("esempio : ")
for carattere in stringa:
    print ("carattere : ", carattere)
    
print ("--- Tipo composto ---")
frutto = "Banana"
lettera = frutto[4]
print ("Stampiamo la quinta lettera : ",lettera)
print()
print("Anche le stringhe vengono indicizzate con il primo carattere in posizione 0.")

print(" --- Lunghezza ---")
print("La funzione len() indica il numero di elementi (caratteri) presenti nella stringa.")
print("len(frutto) = ", len(frutto))

print()
print("Poiché la stringa è indicizzata a 0 l'ultimo carattere avrà posizione len()-1!")
lungh = len(frutto)
# print (fruppo[lungh]) # Errore!
print (frutto[lungh-1])

print()
print("--- Loops ---")
indice = 0
while indice < len(frutto):
    lettera = frutto[indice]
    print(lettera)
    indice = indice + 1
    
print("Il codice precedente è utile se è necessario accedere in modo differente ai singoli caratteri.")
print("Se occorre accedere a tutti i caratteri in modo sequenziale, usare il ciclo for.")
for lettera in frutto:
    print(lettera)
    
print ("Ed ecco un primo esempio di manipolazione di stringhe")
print("creiamo un elenco di aggettivi, e li trasformiamo in avverbi")

aggettivi = ["veloce", "attenta", "statica", "serena", "rapida"]
avverbi = "mente"
for elemento in aggettivi:
    print(elemento + avverbi)