# Programma per il calcolo di somma e media di un insieme di dati forniti

# Variabile per il conteggio
Count = 0
# Variabile per la somma
Somma = 0
# Variabile per la media
Media = 0
# Variabile per il valore attuale da confrontare        
temp = 1

while temp != 0:
    temp = int(input("Inserisci un valore, o 0 per uscire : "))
    # Se immetto 0 per uscire dal ciclo,  non devo inserirlo tra i valori da controllare
    if temp != 0:
        Count += 1
        Somma += temp
    
print("Sono stati immessi ", Count, " valori.") 
print("La loro somma è pari a ", Somma)

if Count > 0:
    Media = Somma / Count
    print("La media è pari a ", Media)
else:
    print("Non è stato immesso alcun elemento!")