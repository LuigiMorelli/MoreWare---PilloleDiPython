import random
# Come lavorare con una matrice 3x3 
mA=[ [2,7,4], [1,0,1], [4,6,7] ]

L = len(mA)

# Stampa matrice
for row in range(L):
    for col in range(L):
        #print (mA[row][col])
        print (mA[row][col], end=" ")
    print()

print ("---")

# Creare una seconda matrice 3x3 con valori a caso
mB = []
for row in range(3):
    riga = []
    for col in range(3):
        riga.append(random.randint(0,40))
    mB.append(riga)
        
# Stampa matrice
for row in range(3):
    for col in range(3):
        #print (mA[row][col])
        print (mB[row][col], end=" ")
    print()