dispari = [1, 3, 5, 7, 9]
pari = [0, 2, 4, 6, 8]

print ("Accesso sequenziale in lista") 
print ("Lista numeri pari : ")
for numero in pari:
    print (numero)

print ("Lista numeri dispari : ")
for numero in dispari:
    print (numero)

print ("---")

print ("Accesso posizionale diretto")
print ("Lista numeri pari : ")
for i in range(len(pari)):
    print (pari[i])

print ("Lista numeri dispari : ")
for i in range(len(dispari)):
    print (dispari[i])