# Definiamo una funzione per la stampa di matrici
import random

def Stampa_matrice(Mat):
    L = len(Mat)
    for row in range(L):
        for col in range(L):
            #print (mA[row][col])
            # print (mA[row][col], end=" ")
            print ("%2i" % Mat[row][col], end=" ")
        print()


mA=[ [2,7,4], [1,0,1], [4,6,7] ]

L = len(mA)

Stampa_matrice(mA)

print ("---")

# Creare una seconda matrice 3x3 con valori a caso
mB = []
for row in range(3):
    riga = []
    for col in range(3):
        riga.append(random.randint(0,40))
    mB.append(riga)
        
Stampa_matrice(mB)
