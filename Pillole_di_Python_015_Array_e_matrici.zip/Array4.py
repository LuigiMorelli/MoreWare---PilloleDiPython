# Definizione di funzioni pre le matrici
import random

def Stampa_matrice(Mat):
    L = len(Mat)
    for row in range(L):
        for col in range(L):
            #print (mA[row][col])
            # print (mA[row][col], end=" ")
            print ("%2i" % Mat[row][col], end=" ")
        print()

def Crea_matrice(n):
    mz = []
    for row in range(n):
        riga = []
        for col in range(n):
            riga.append(random.randint(0,40))
        mz.append(riga)
    return mz

def Somma_matrici(m1, m2):
    l = len(m1)
    mz = Crea_matrice(l)
    for row in range(l):
        for col in range(l):
            mz[row][col] = m1[row][col] + m2[row][col]
    return mz

mA=[ [2,7,4], [1,0,1], [4,6,7] ]

L = len(mA)

print ("Matrice mA")
Stampa_matrice(mA)

print ("---")

# Creare una seconda matrice 3x3 con valori a caso
mB = Crea_matrice(3)

print ("Matrice mB")
Stampa_matrice(mB)

print ("---")

# Somma matrici
mSomma = Somma_matrici(mA, mB)

print ("Matrice mA + mB")
Stampa_matrice(mSomma)



