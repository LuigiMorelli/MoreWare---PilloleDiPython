from random import randint
numeri = 10
#vettore = [5,5,5,6,5,5,5,4,5,5]
vettore = [111, 4, 13, 91, 55, 42, 37, 51,42, 0]

#Stampa lista
for n in range(numeri):
    print("%5d" % (vettore[n]), end="")
    
#Stampa media
print ("\nMedia = ", sum(vettore) / len(vettore))

#Calcolo mediana: ordinamento ed estrazione
vettore.sort()
elementi = len(vettore)
indice_mediana = elementi // 2 #divisione intera
print ("Mediana = ", vettore[indice_mediana])

#Usiamo un dizionario per determinare le frequenze dei valori
freq = dict()
for n in vettore:
    if n not in freq:
        freq[n] = 1
    else:
        freq[n] += 1
print ("Frequenze per ciascun elemento : ")
for key in freq:
    print("%4d, %4d" % (key, freq[key]))