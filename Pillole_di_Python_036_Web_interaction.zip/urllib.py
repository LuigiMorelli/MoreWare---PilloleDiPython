import urllib.request
fhand = urllib.request.urlopen('https://www.moreware.org/temp/commedia.txt')

for line in fhand:
    print(line.decode().strip())