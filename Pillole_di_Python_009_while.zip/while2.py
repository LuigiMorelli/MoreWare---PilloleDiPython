indice = 10
while indice < 20:
    print(indice)
    indice = indice + 1