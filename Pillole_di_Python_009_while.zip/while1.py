##Codice if
##se la condizione è vera:
##    esegui il
##    codice
##    interno
##
##poi esegui il resto

a = 5
if a == 5:
    print("a = 5")

print("---")

##Codice for
##per un indice che va da a a b:
##    esegui il
##    codice
##    interno
##    (aggiorna indice)

indice = 0
for indice in range (10,20):
    print(indice)
    
print("---")

### Codice while
##finché condizione è vera:
##    esegui il
##    codice
##    interno
##    (aggiorna la condizione)
##poi esegui il resto

indice = 10
while indice < 20:
    print(indice)
    indice = indice + 1