while True:
    a = int(input("Immetti un numero : "))
    if a == 0:
        print("uscita dal ciclo")
        break
    print("Il numero immesso è ", a)