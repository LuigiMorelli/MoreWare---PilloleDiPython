# Il programma gestisce una serie di nomi in attesa per una visita.
# Utilizza un menù per controllare una lista.

nomi = []   # Lista vuota per i nomi

# Abbiamo 4 comandi possibili nel nosto menù di operazioni.
# Il comando immesso dall'utente verrà inserito nella variabile cmd

cmd = ""
while cmd != '4':
    print ("1 - Lista nomi");
    print ("2 - Aggiungi nome");
    print ("3 - Chiama nuovo paziente")
    print ("");
    print ("4 - Uscita");
    
    cmd = input("\tIstruzione : ")
    
    if cmd == '1':
        for nome in nomi:
            print (nome)
        print("")
    elif cmd == '2':
        nuovoNome = input ("Nome : ")
        nomi.append(nuovoNome)
    elif cmd == '3':
        if len(nomi) == 0:
            print ("\nNon ci sono altri pazienti!\n")
        else:
            nuovoPaziente = nomi[0]
            nomi.remove(nuovoPaziente)
            print ("\nStiamo chiamando %s!\n" % nuovoPaziente)
    elif cmd != 4:
        print ("\nComando non valido!\n")