import random           # Modulo per definire numeri a caso
import numpy as np      # Modulo per il calcolo numerico
from timer import Timer # Modulo per il calcolo del tempo trascorso

# Definizione delle funzioni
def set_lista(n):
    for i in range(n):
        lista.insert(i, (random.randint(1,n)))

def bubble_sort(x):
    for i in range(len(x)-1):
        for j in range(i+1, len(x)):
            if x[i] > x[j]:
                (x[i], x[j]) = (x[j], x[i])
    return x

def selection_sort(x):
    for i in range(len(x)):
        swap = i + np.argmin(x[i:])
        (x[i], x[swap]) = (x[swap], x[i])
    return x

def Salva_stato(x):
    f = open("elementi_ordinati.txt", "w")
    for elemento in x:
        f.write(str(elemento) + "\n")
        

# Il programma inizia qui
t = Timer(text="Tempo di esecuzione: {:.6f} secondi.")

for i in (10, 100, 1000):
    print("\nLista con " + str(i) + " elementi:")
    t.start()
    lista = []
    print("Creazione lista...")
    random.seed()
    set_lista(i)
    x = np.array(lista)
    t.stop()

    print("Valutazione sorting.")

         
    t.start()
    print("Bubble sort...")
    bubble_sort(x)
    t.stop()

    t.start()
    print("Selection sort...")
    selection_sort(x)
    t.stop()

    t.start()
    print("Numpy sort (quicksort)...")
    np.sort(x)
    t.stop()

# Salva il risultato finale in un file
Salva_stato(x)