# Seconda variante:
# Non corregge errori dovuti a:
#     a = 0
# Corregge il problema del calcolo del delta negativo, ma non avverte l'utente di non poter calcolare le soluzioni.

from math import sqrt

def calc_delta(a, b, c):
    return (b*b - 4*a*c)

a = int(input("immettere il valore di a : "))
b = int(input("immettere il valore di b : "))
c = int(input("immettere il valore di c : "))

delta = calc_delta(a, b, c)

if delta >= 0:
    s1 = (-b + sqrt(delta))/(2*a)
    s1 = (-b - sqrt(delta))/(2*a)

    print("Soluzione 1 : ", s1)
    print("Soluzione 2 : ", s2)
