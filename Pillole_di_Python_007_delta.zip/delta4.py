# Variante finale funzionante
# Ricerca delle soluzioni dell'equazione di secondo grado
# nella forma ax^2 + bx + c = 0
#
from math import sqrt

# Funzione per il calcolo del delta
def calc_delta(a, b, c):
    return (b*b - 4*a*c)
    
a = float(input("immettere il valore di a : "))
b = float(input("immettere il valore di b : "))
c = float(input("immettere il valore di c : "))

# Se a = 0 abbiamo una equazione di primo grado da discutere
if a == 0:
    print("L'equazione richiesta è di primo grado!")
    if b != 0:
        print("La soluzione è -c/b! ", -c/b)
    else:
        if c != 0:
            print("a = 0, b = 0, c diverso da zero : equazione impossibile.")
        else:
            print("c = 0")
# ...altrimenti discutiamo l'equazione di secondo grado
else:
    # Calcoliamo il "delta" dell'equazione, uguale a b^2 - 4 ac
    delta = calc_delta(a, b, c)

    # Valutiamo il risultato del delta
    if delta < 0:
        print("Delta < 0 : Soluzioni complesse coniugate")
    elif delta == 0:
        print("Delta = 0 : due soluzioni reali coincidenti")
    else:
        print("Delta > 0 : Due soluzioni reali distinte")
        
    # Risolviamo l'equazione per delta >= 0
    if delta >= 0:
        s1 = (-b + sqrt(delta))/(2 * a)
        s2 = (-b - sqrt(delta))/(2 * a)

        # Stampiamo i risultati
        print("Soluzione 1 : ", s1)
        print("Soluzione 2 : ", s2)
