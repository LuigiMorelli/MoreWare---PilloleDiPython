# Programma base
# Non corregge errori dovuti a:
#     a = 0
# delta < 0
from math import sqrt

a = int(input("immettere il valore di a : "))
b = int(input("immettere il valore di b : "))
c = int(input("immettere il valore di c : "))

s1 = (-b + sqrt(b*b - 4*a*c))/(2*a)
s2 = (-b - sqrt(b*b - 4*a*c))/(2*a)

print("Soluzione 1 : ", s1)
print("Soluzione 2 : ", s2)