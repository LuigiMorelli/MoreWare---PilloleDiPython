inp = input("Inserisci il valore in pollici, da convertire in centrimetri: ")
pollici = float(inp)
cm = pollici * 2.54
print(pollici," pollici corrispondono a ", cm, " centimetri.")