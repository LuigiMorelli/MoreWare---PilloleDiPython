inp = input("Inserisci la temperatura in °C, da convertire in °F: ")
C = float(inp)
F = (C * 1.8) + 32
print(C," gradi Celsius corrispondono a ", F, " gradi Fahrenheit.")