inp = input("Inserisci il valore in dollari, da convertire in euro: ")
dollari = float(inp)
euro = dollari * 0.9
print(dollari," dollari corrispondono a ", euro, " euro.")