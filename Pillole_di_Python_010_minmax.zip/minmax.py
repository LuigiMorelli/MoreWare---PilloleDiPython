# Programma per la ricerca del valore minimo e massimo in un insieme di dati forniti

# Variabile per il minimo temporaneo
min = 1000000000
# Variabile per il massimo temporaneo
Max = -1000000000
# Variabile per il valore attuale da confrontare        
temp = 1

# Controlla se il valore è maggiore del massimo temporaneo
def testMax ():
    global Max
    if temp > Max:
        Max = temp

# Controlla se il valore è inferiore al minimo temporaneo
def testmin():
    global min
    if temp < min:
        min = temp

while temp != 0:
    temp = int(input("Inserisci un valore tra -100.000 e 100.000, o 0 per uscire : "))
    # Se immetto 0 per uscire dal ciclo,  non devo inserirlo tra i valori da controllare
    if temp != 0:
        testMax()
        testmin()
    
print("Il maggiore valore immesso è ", Max) 
print("Il  minore  valore immesso è ", min) 
