count = 0
n = 999999999
r = 0

min = int(input("Inserisci il minimo  del dominio di scelta : "))
Max = int(input("Inserisci il massimo del dominio di scelta : "))

while n != 0:
    count = count + 1
 
    r = min + ((Max - min) // 2)
    
    print ("Scelgo il numero ",r)

    print ("    Se ho indovinato inserisci 0")
    print ("    Se il tuo numero è superiore a ", r, " inserisci 1")
    print ("    Se il tuo numero è inferiore a ", r, " inserisci 2")
    
    n = int(input())
        
    if n == 1:
        min = r
    elif n == 2:
        Max = r
    else:
        print ("Ho indovinato il tuo numero in ", count, " tentativi!")    
    