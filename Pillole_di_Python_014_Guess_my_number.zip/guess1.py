import random

count = 0
n = 0
r = 0

min = int(input("Inserisci il minimo  del dominio di scelta : "))
Max = int(input("Inserisci il massimo del dominio di scelta : "))

n = random.randint(min, Max)

while n != r:
    count = count + 1
    
    r = int(input("Inserisci la tua scelta : "))
    
    if r < n:
        print ("Il tuo numero è minore  di quello scelto da me!")
    elif r > n:
        print ("Il tuo numero è maggiore di quello scelto da me!")
    else:
        print ("Hai indovinato il mio numero in ", count, " tentativi!")    
    