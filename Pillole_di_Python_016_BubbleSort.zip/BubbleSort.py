# Definiamo una lista di valori da ordinare:
lista = [5, 2, 1, 3, 6, 4]

n = len(lista)

# Swap function 
def swap(lista, i, j):      
    lista[i], lista[j] = lista[j], lista[i] 
    return list

def StampaLista(messaggio):
    print(messaggio)
    for i in range(n):
        print (lista[i])
        
StampaLista("Lista prima del sort")

for i in range(n-1):
    for j in range(i+1, n):
        if lista[i] >= lista[j]:
           swap(lista, i, j)

StampaLista("Lista dopo il sort")