import hashlib

Messaggio = "Moreware hashing test - Stringa di test per funzioni di hashing"

print ("Il valore della stringa è      : ", end="")
print (Messaggio)

result = hashlib.md5(Messaggio.encode())

print ("L'hash MD5 della stringa è     : ", end="")
print (result.hexdigest())

# Ora modifichiamo UN SOLO CARATTERE aggiungendo uno spazio

Messaggio = "Moreware hashing test - Stringa di test per funzioni di hashing "

print ("Il valore della stringa è      : ", end="")
print (Messaggio)

result = hashlib.md5(Messaggio.encode())

print ("L'hash MD5 della stringa è     : ", end="")
print (result.hexdigest())