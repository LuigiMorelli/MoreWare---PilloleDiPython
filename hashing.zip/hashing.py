import hashlib

Messaggio = "Moreware hashing test - Stringa di test per funzioni di hashing"

print ("Il valore della stringa è      : ", end="")
print (Messaggio)

result = hashlib.md5(Messaggio.encode())

print ("L'hash MD5 della stringa è     : ", end="")
print (result.hexdigest())

result = hashlib.sha1(Messaggio.encode())

print ("L'hash SHA-1 della stringa è   : ", end="")
print (result.hexdigest())

result = hashlib.sha256(Messaggio.encode())

print ("L'hash SHA-256 della stringa è : ", end="")
print (result.hexdigest())

result = hashlib.sha512(Messaggio.encode())

print ("L'hash SHA-512 della stringa è : ", end="")
print (result.hexdigest())