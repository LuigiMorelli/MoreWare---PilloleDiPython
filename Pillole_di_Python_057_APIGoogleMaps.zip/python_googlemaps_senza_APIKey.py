import googlemaps
from datetime import datetime

gmaps = googlemaps.Client(key='Inserire qui la vostra API Key')

Indirizzo_generico = "via San Rocco 11 24040 Bonate Sopra Bergamo"

# Geocoding an address
print("Geocodifica di un indirizzo in coordinate Lat/Lng : ")
geocode_result = gmaps.geocode(Indirizzo_generico)
print(geocode_result)
print("")

# Look up an address with reverse geocoding
print("Geocodifica inversa: da coordinate a indirizzo : ")
reverse_geocode_result = gmaps.reverse_geocode((40.714224, -73.961452))
print(reverse_geocode_result)
print("")

# Request directions via public transit
print("Stampa itinerario e tempi di percorrenza : ")
now = datetime.now()
directions_result = gmaps.directions("Sydney Town Hall",
                                     "Parramatta, NSW",
                                     mode="transit",
                                     departure_time=now)
print(directions_result)
print("")

# Validate an address with address validation
addressvalidation_result =  gmaps.addressvalidation(['1600 Amphitheatre Pk'], 
                                                    regionCode='US',
                                                    locality='Mountain View', 
                                                    enableUspsCass=True)
print("Validazione dell'indirizzo : \n", addressvalidation_result)
print("")


# Definisco l'indirizzo completo dalle coordinate

elem = (reverse_geocode_result[0])
print("Definisco l'indirizzo completo dalle coordinate : ")
print(elem['address_components'])

print("\nEnumero gli elementi della lista degli indirizzi : ")
for single in elem['address_components']:
    print("    ", single) 

# Stampo alcune componenti dell'indirizzo

print("\nStampo alcune componenti dell'indirizzo :")
numero = elem['address_components'][0]['long_name']
indirizzo = elem['address_components'][1]['long_name']
localita = elem['address_components'][2]['long_name']
citta = elem['address_components'][3]['long_name']
print("Numero civico : ", numero, " indirizzo : ", indirizzo, " localita : ", localita, "citta : ", citta)

# Calcolo la distanza tra due indirizzi
print("\nCalcolo la distanza tra due indirizzi : ")
distanza = gmaps.distance_matrix(Indirizzo_generico, 'viale Mazzini 11 00142 Roma')
print("Distanza : ", distanza)

# Stampo gli elementi provenienti dalla geocodifica di un indirizzo
print("\nStampo gli elementi provenienti dalla geocodifica di un indirizzo : ")
coord = gmaps.geocode(Indirizzo_generico)
print(coord[0])

print("\nEnumero ciascuno degli elementi della lista : ")
for elem in coord[0]:
    print(elem)
    

# Stampo una stringa formattata da un indirizzo generico
ind_formattato = coord[0]['formatted_address']
print("Stampo una stringa formattata da un indirizzo generico : ", ind_formattato)


#Estraggo Latitudine e Longitudine dal record dell'indirizzo richiesto
print("\nEstraggo Latitudine e Longitudine dal record dell'indirizzo richiesto (e la classe dell'elemento ottenuto) : ")
LatLng = [(coord[0]['geometry']['location']['lat'], coord[0]['geometry']['location']['lng'])]
print (LatLng, type(LatLng))

# ...e calcolo l'elevazione sul livello del mare, utilizzando i dati appena estratti
print("\n...e calcolo l'elevazione sul livello del mare, utilizzando i dati appena estratti")
elevazione = gmaps.elevation(LatLng)
print(elevazione)
