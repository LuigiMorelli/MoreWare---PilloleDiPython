# Utility method to return 
# sum of square of digit of n
def numSquareSum(n):
    squareSum = 0;
    while(n):
        squareSum += (n % 10) * (n % 10);
        print ("squareSum = ", squareSum)
        n = int(n / 10);
    print ("---")
    return squareSum;
 
# method return true if
# n is Happy number
def isHappynumber(n):
 
    # initialize slow 
    # and fast by n
    slow = n;
    fast = n;
    while(True):
         
        # move slow number
        # by one iteration
        slow = numSquareSum(slow);
        print ("slow = ", slow)
        # move fast number
        # by two iteration
        fast = numSquareSum(numSquareSum(fast));
        print ("slow, fast = ", slow, fast)
        if(slow != fast):
            continue;
        else:
            break;
 
    # if both number meet at 1, 
    # then return true
    return (slow == 1);
 
# Driver Code
n = 12;
if (isHappynumber(n)):
    print(n , "is a Happy number")
else:
    print(n , "is not a Happy number")