def calculate_celsius(kelvin):
    celsius = kelvin - 273
    return celsius
    
def calculate_fahrenheit(kelvin):
    fahrenheit = (kelvin - 273) * 9 / 5 + 32
    return fahrenheit

c = calculate_celsius(340)
f = calculate_fahrenheit(340)

print (c)
print(f)