def countdown(n):
    if n == 0:
        print("Lancio avvenuto!")
    else:
        print(n)
        countdown(n-1)
        
countdown (3)
    