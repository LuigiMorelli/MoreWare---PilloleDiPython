def ricorsione():
    ricorsione()
    
ricorsione()