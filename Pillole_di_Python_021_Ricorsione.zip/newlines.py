def newlines(n):
    if n > 0:
        print()
        newlines(n-1)
        
newlines(5)