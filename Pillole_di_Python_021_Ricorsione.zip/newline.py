def newline():
    print()
    
def trelinee():
    print()
    print()
    print()
    
newline()
trelinee()