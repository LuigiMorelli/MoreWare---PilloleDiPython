f = open("Esempio.txt", "r")
for lines in f:
    print(lines.rstrip('\n'))
f.close