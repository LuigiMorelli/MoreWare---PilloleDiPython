f = open("Esempio.txt", "a")
f.write("Wilma,10000\n")
f.close()