# Esempio gestione file
players = ['Fred,10000', 'Barney,15000', 'Derek,12000', 'Janet,17000']

f = open ("Esempio.txt", "w")
for p in players:
    f.write(p + '\n')
f.close()

#Apertura e lettura massiva del file
f = open ("Esempio.txt", "r")
print(f.read())
f.close()

#Lettura con for
f = open("Esempio.txt")
for lines in f:
    print(lines) 
f.close()

f = open("Esempio.txt", "a")
f.write("Wilma,10000\n")
f.close

f = open("Esempio.txt", "r")
for lines in f:
    print(lines.rstrip('\n'))
f.close