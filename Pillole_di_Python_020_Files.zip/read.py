#Apertura e lettura massiva del file
f = open ("Esempio.txt", "r")
print(f.read())
f.close()

#Lettura con for
f = open("Esempio.txt")
for lines in f:
    print(lines)
    
f.close()