lista = [1,'2', "tre",[4,"pippo", 3.28]]
dizionario = {"uno" : "one", "due" : "two", "tre" : "three"}

for elemento in lista:
    print(elemento)
    
print("-----")

for key in dizionario:
    print(dizionario[key])