def linearSearch(alist, item):
    for i in alist:
        if i == item:
            print (item, " presente in posizione ", alist.index(item))
            return True
    print(item, " non presente in lista.")
    return False
    
testlist = [0, 1, 2, 8, 13, 17, 19, 32, 42,]
print(linearSearch(testlist, 3))
print(linearSearch(testlist, 13))

